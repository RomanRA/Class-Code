
<div class = "navbar navbar-default navbar-fixed-bottom">
    <div class = "container">
        <p class = "navbar-text pull-right">Copyright Richard Roman</p>
<!--        <a href ="#" class=" btn btn-default btn pull-right">Information</a>-->
    </div>
</div>