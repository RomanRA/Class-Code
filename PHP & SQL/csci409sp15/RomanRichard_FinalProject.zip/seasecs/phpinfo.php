<?php
/**
 * Created by PhpStorm.
 * User: Richard
 * Date: 3/26/2015
 * Time: 11:19 AM
 */
phpinfo();

?>