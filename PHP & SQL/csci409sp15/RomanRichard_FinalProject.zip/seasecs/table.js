$(document).ready(function() {
    $('#information').dataTable( {
        "order": [[ 1, "asc" ]]
    });
} );