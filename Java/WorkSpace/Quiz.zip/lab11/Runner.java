/**
 * Runner.java - contains main that calls the other classes in this package
 * @author Richard A Roman
 * @author Clint
 * Course: 150
 * Lab11
 * Email: raroman@coastal.edu
 * Date: 11/19/2013
 */
import view.MainFrame;

public class Runner {
	
	public static void main(String[] args) {
		
		MainFrame  testFrame = new MainFrame("Shapes and Stuff");
	}

}
