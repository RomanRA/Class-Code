/**
 * Drawable.java 
 * @author Richard A Roman
 * @author Clint
 * Course: 150
 * Lab11
 * Email: raroman@coastal.edu
 * Date: 11/19/2013
 */
package model;

import java.awt.Graphics;

public interface Drawable {
	public void draw(Graphics g);

}
