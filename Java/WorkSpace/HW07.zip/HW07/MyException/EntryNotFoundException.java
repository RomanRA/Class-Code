package MyException;

public class EntryNotFoundException extends Exception {

	public EntryNotFoundException(String message){
		System.out.println(message);
	}
}



